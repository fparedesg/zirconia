# zirconia
Toy project to learn about Chrome extensions. Displays tab previews when you hover under the tab bar.
